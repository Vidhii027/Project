import './App.css';
import Home from './Components/Home';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import NavBar from './Components/NavBar';
import AddUser from './Components/AddUser';

function App() {
  return (
    <BrowserRouter>
    <NavBar/>
      <Routes>
        <Route path="/" element={<Home />}/>
        <Route path="/addUser" element={<AddUser />}/>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
